导出时间: 2026-02-18 20:02:32
任务ID: 2464b10910014bb3a83beb1620697cb6
规则名称: ces
模型文件: predict_power.py
模型版本: v3.0.1
时间范围: 2026-03-01T10:00 ~ 2026-03-01T10:30

文件清单:
metadata/task.json | size=441 | md5=087d3ba3dcc2a920b1166f95539aa887
model/predict_power.py | size=324 | md5=fd1d1aed6f71e7def882ea417def3bbc
data/input.csv | size=70 | md5=2f9ed7513678ff522e407282b672e4b7
data/output.csv | size=73 | md5=c9dfbb9d0648beb1c6973272d4d3dc19

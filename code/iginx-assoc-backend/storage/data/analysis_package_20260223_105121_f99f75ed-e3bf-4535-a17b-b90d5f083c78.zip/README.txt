导出时间: 2026-02-23 10:51:21
任务ID: b4a9ab645c79437799ecf57729a45205
规则名称: dada
模型文件: predict_power.py
模型版本: v1.0.0
时间范围: 2026-03-01T12:00 ~ 2026-03-01T14:00

文件清单:
metadata/task.json | size=443 | md5=71bff4a83617f5cc9b05cc5e4883b18b
data/input.csv | size=4487 | md5=6106f5b473f2122d145be0d95179ccaa
data/output.csv | size=4100 | md5=274b10052a21906d64de393bb7c2ef81

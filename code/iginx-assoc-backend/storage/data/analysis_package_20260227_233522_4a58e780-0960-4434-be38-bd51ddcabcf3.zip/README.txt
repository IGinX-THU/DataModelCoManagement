导出时间: 2026-02-27 23:35:22
任务ID: 024f15aa8f8c449ab9f4de353581c608
规则名称: gregrdeg
模型文件: predict_power.py
模型版本: v1.0.0
时间范围: 2026-02-27T22:52 ~ 2026-03-17T23:22

文件清单:
metadata/task.json | size=379 | md5=f4b89ff63c51f5b3a4188d7d1b8377bb
model/predict_power.py | size=324 | md5=fd1d1aed6f71e7def882ea417def3bbc
data/input.csv | size=952763 | md5=202759bc94938c0806183bf2bf519438
data/output.csv | size=849402 | md5=51c178951a76dbb71dfa52602c608a5f
